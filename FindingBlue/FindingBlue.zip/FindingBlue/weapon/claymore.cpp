#include"../claymore.h"


void CLAYMORE::update(float deltaTime, glm::vec3 position, float yaw, float pitch)
{
    if (!this->is_get) {
		
		metal.rotation.y += glm::radians(60.0f) * deltaTime;
    }
    else if (this->is_get) {
        this->position = position;
        this->front = front;


        // ī�޶� ���� front ���� ���
        glm::vec3 front;
        front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
        front.y = sin(glm::radians(pitch));
        front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
        front = glm::normalize(front);

        glm::vec3 right = glm::normalize(glm::cross(front, glm::vec3(0, 1, 0)));
        glm::vec3 up = glm::normalize(glm::cross(right, front));


        glm::vec3 offset = right * 0.2f   // ȭ�� ����������
            + up * -0.7f    // ȭ�� �Ʒ���
            + front * 0.8f; // ȭ�� ��������
  

        glm::vec3 gunPos = position + offset;

        // �� ��ġ ����
        this->wood.position = gunPos;
        this->metal.position = gunPos;
        //���⼳��
        wood.rotation.y = -glm::radians(yaw)+glm::radians(90.0f);
        metal.rotation.y = -glm::radians(yaw) + glm::radians(90.0f);
        wood.rotation.z = glm::radians(pitch);
        metal.rotation.z = glm::radians(pitch);

        //�����´���
        wood.rotation.y += this->attack_offsets.y;
		metal.rotation.y += this->attack_offsets.y;

        wood.rotation.z += this->attack_offsets.z;
		metal.rotation.z += this->attack_offsets.z;
    }

}

bool CLAYMORE::get_weapon(glm::vec3 playerPos) {
	float distance = glm::length(playerPos - this->metal.position);
	if (distance < 1.5f&&!this->is_get) {
		this->is_get = true;
        return true;
	}
    return false;
}

void CLAYMORE::attack(float deltaTime) {
    //�̰� x�࿡���� ȸ�������Ұ���
    if (!this->recoil_mode) {
        //�� ������ �ڷ�
        //�� ������ ������
        this->attack_offsets.z -= glm::radians(800.0f * deltaTime);
	
        if (this->attack_offsets.z < glm::radians(-90.0f)) {
            this->recoil_mode = true;
            this->attack_offsets.z = glm::radians(-90.0f);
   

        }
    }
    else if (this->recoil_mode) {
       
        this->attack_offsets.z += glm::radians(200.0f * deltaTime);
    
        if (this->attack_offsets.z > glm::radians(0.0f)) {
            this->recoil_mode = false;
            this->attack_offsets.z = glm::radians(0.0f);
            this->on_attak = false;
    
        }
    }
   metal.rotation.z=wood.rotation.z = this->attack_offsets.z;
}
void CLAYMORE::zoom_in(bool mode, float deltaTime) {
	//������ ���θ�� ����
}