#include"../ak_47.h"

#include<iostream>
void AK_47::update(float deltaTime, glm::vec3 position, float yaw, float pitch)
{
    if (!this->is_get) {
		wood.rotation.y += glm::radians(60.0f) * deltaTime;
		metal.rotation.y += glm::radians(60.0f) * deltaTime;
    }

    else if (this->is_get) {
        this->position = position;
        this->front = front;


        // ī�޶� ���� front ���� ���
        glm::vec3 front;
        front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
        front.y = sin(glm::radians(pitch));
        front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
        front = glm::normalize(front);
        this->front = front;
        glm::vec3 right = glm::normalize(glm::cross(front, glm::vec3(0, 1, 0)));
        glm::vec3 up = glm::normalize(glm::cross(right, front));


        glm::vec3 offset = right * (0.2f+this->offsets.x)   // ȭ�� ����������
            + up * ( - 0.2f+this->offsets.y)    // ȭ�� �Ʒ���
            + front * (0.3f+this->offsets.z); // ȭ�� ��������

        glm::vec3 gunPos = position + offset;
        this->for_bullet_offset = gunPos;
        this->for_bullet_offset.y += 0.1f;
        // �� ��ġ ����
        this->wood.position = gunPos;
        this->metal.position = gunPos;
        //���⼳��
        wood.rotation.y = -glm::radians(yaw);
        metal.rotation.y = -glm::radians(yaw);
        wood.rotation.z = glm::radians(pitch);
        metal.rotation.z = glm::radians(pitch);
    }

    for (int i = bullets.size() - 1; i >= 0; --i)
    {
        BULLET* b = bullets[i];

        if (b->update(deltaTime,yaw,pitch)) // ���� ���� ����?
        {
            delete b;            // �޸� ����
            bullets.erase(bullets.begin() + i);  // ���Ϳ��� ����
        }
    }

}

bool AK_47::get_weapon(glm::vec3 playerPos) {
	float distance = glm::length(playerPos - this->wood.position);
	if (distance < 1.5f && !this->is_get) {
		this->is_get = true;
		return true;
	}
    return false;

}

void AK_47::attack(float deltaTime) {
	//�� �ݵ� ����
    if (!this->recoil_mode) {
        //�� ������ �ڷ�
		this->offsets.z += 3.0f*deltaTime;
		if (this->offsets.z > 0.1f) {
			this->recoil_mode = true;
            this->offsets.z = 0.1f;
            //�� �κп� �Ѿ� ���� ������ �ɰŰ���
			bullets.push_back(shoot_bullet(this->for_bullet_offset, this->front));
            //std::cout << this->front.x << " " << this->front.y << " " << this->front.z << std::endl;
		}
	}
    else if (this->recoil_mode) {
        //�� ������ ������
        this->offsets.z -= 3.0f * deltaTime;
        if (this->offsets.z < 0.0f) {
            this->recoil_mode = false;
            this->offsets.z = 0.0f;

        }
    }
}

void AK_47::zoom_in(bool mode, float deltaTime) {
    //���ظ�� ����
    if (mode) {
        //������ y�� ���̱�
        offsets.x -= 0.1f * deltaTime;
        if (offsets.x) {
            offsets.x < -0.2f;
            offsets.x = -0.2f;
        }
    }
    else if (!mode) {
        //������ y�� �ø���
        offsets.x += 1.0f * deltaTime;
        if (offsets.x > 0.0f) {
            offsets.x = 0.0f;
        }
    }
}

BULLET* shoot_bullet(glm::vec3 postion, glm::vec3 direction) {
	BULLET* new_bullet;
	new_bullet = new BULLET();
	new_bullet->init();
	new_bullet->set_position(postion);
	new_bullet->set_front(direction);
	return new_bullet;
}