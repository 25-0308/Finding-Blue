#include "../TextManager.h"

std::unordered_map<std::string, GLuint> TextureManager::texCache;
