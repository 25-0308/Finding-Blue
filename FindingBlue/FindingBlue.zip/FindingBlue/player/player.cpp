#include "../Player.h"
#include <GL/glm/gtc/matrix_transform.hpp>
#include<iostream>
void Player::move(float deltaTime)
{
    glm::vec3 forward = glm::normalize(glm::vec3(front.x, 0.0f, front.z));
    glm::vec3 right = glm::normalize(glm::cross(forward, up));
	glm::vec3 nextposition = position;
	
    //���� �̵���ΰ� ���̸� �̵����ϰ�
	//�Ϻη� �� ¥ġ�� ������� ��Ȯ�ϰ��Ϸ��� 0.05�� �� �ϸ��
	if (nextposition.x < -2.2f) nextposition.x = -2.2f;
	if (nextposition.z < -2.2f) nextposition.z = -2.2f;
	if (nextposition.x > 97.0f) nextposition.x = 97.0f;
	if (nextposition.z > 97.0f) nextposition.z = 97.0f;
	if (keys['w']) {
		nextposition += forward * speed * deltaTime;
	}
	if (keys['s']) {
		nextposition -= forward * speed * deltaTime;
	}
	if (keys['a']) {
		nextposition -= right * speed * deltaTime;
	}
	if (keys['d']) {
		nextposition += right * speed * deltaTime;
	}
	position = nextposition;
}
void Player::change_weapon(int index)
{
	if (index >= 0 && index < weapons.size()) {
		currentWeapon = index;
	}
}

void Player::zoom_in(float deltaTime) {
	if (this->zoom_mode) {
		FOV -= 30.0f * deltaTime;
		if (FOV < 35.0f) FOV = 35.0f;

		//�ϴ� �Ѻ��� ��ġ����
		if (!this->weapons.empty())
		this->weapons[currentWeapon]->zoom_in(true, deltaTime);

	}
	else if (!this->zoom_mode) {
		FOV += 30.0f * deltaTime;
		if (FOV > 45.0f) FOV = 45.0f;
		if(!this->weapons.empty())
		this->weapons[currentWeapon]->zoom_in(false, deltaTime);
	}
}