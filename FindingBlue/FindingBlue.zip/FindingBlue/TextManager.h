#pragma once
#include <string>
#include <unordered_map>
#include <gl/glew.h>

GLuint LoadTexture(const char* path); // ���� �δ� �״�� ���

class TextureManager {
private:
    static std::unordered_map<std::string, GLuint> texCache;

public:
    static GLuint GetTexture(const std::string& path) {
        // �̹� �ε�� ���
        if (texCache.find(path) != texCache.end())
            return texCache[path];

        // ���� �ε�
        GLuint tex = LoadTexture(path.c_str());
        texCache[path] = tex;
        return tex;
    }

    static void Clear() {
        for (auto& t : texCache)
            glDeleteTextures(1, &t.second);
        texCache.clear();
    }
};
